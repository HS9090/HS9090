<?php
@include '../config.php';

if(isset($_POST['add_product'])){
   $p_name = $_POST['p_name'];
   $p_price = $_POST['p_price'];
   $description = $_POST['description'];
   $p_image = $_FILES['p_image']['name'];
   $p_image_tmp_name = $_FILES['p_image']['tmp_name'];
   $p_image_folder = '../uploaded_img/'.$p_image;

   $insert_query = mysqli_query($conn, "INSERT INTO `products`(p_name, p_price, p_image, description)
    VALUES('$p_name', '$p_price', '$p_image','$description')") or die('query failed');

   if($insert_query){
      move_uploaded_file($p_image_tmp_name, $p_image_folder);
      $message[] = 'product add succesfully';
   }else{
      $message[] = 'could not add the product';
   }
};

?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Dashboard</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   };
};

?>
<section>
	<div class="sidebar">
		<h1 class="logo">Admin</h1>

		<ul class="nav">
			<li><a href="admin.html"><i class="fa fa-windows"></i> Dashboard</a></li>
			<li class="active"><a href="add-product.html"><i class="fa fa-cube"></i> Product</a></li>

		</ul>

	</div>
	<div class="main">
		
		<div class="head-section">
			<div class="col-6">
				<h2>Welcome</h2>
				<p>Adminstrator</p>
			</div>

			<div class="col-6" style="text-align: right;">
				<input type="text" class="search">
				<i class="fa fa-search hicon sicon"></i>

				<img src="img/admin.png" class="user">

				<div class="profile-div">
					<a href="sitting.html"><p><i class="fa fa-user"> Profile </p></i></a>    
					<p><i class="fa fa-power-off"></i>   Log Out</p>
				</div>

			</div>

			<div class="clearfix"></div>
		</div>

		<br><br>
		<div class="content">



            <div class="container tm-mt-big tm-mb-big">
                <div class="row">
                  <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
                    <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
                      <div class="row">
                        <div class="col-12">
                          <h2 class="tm-block-title d-inline-block">Add Product</h2>
                        </div>
                      </div>
                      <div class="row tm-edit-product-row">
                        <div class="col-xl-6 col-lg-6 col-md-12">
                          <form action="" method="post" enctype="multipart/form-data"  class="tm-edit-product-form" >
                            <div class="form-group mb-3">
                              <label
                                for="name"
                                >Product Name
                              </label>
                              <input
                                id="name"
                                name="p_name"
                                type="text"
                                class="form-control validate"
                                required
                              />
                            </div>
                            <div class="form-group mb-3">
                              <label
                                for="description"
                                >Description</label
                              >
                              
                              <textarea
                                class="form-control validate"
                                rows="3"
                                name="description"
                                required
                              ></textarea>
                            </div>
                            <div class="form-group mb-3">
                                <label
                                  for="price"
                                  >price
                                </label>
                                <input
                                  id="name"
                                  name="p_price"
                                  type="number"
                                  class="form-control validate"
                                  required
                                />
                              </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 mx-auto mb-4">
                          <div class="tm-product-img-dummy mx-auto">
                            <i
                              class="fas fa-cloud-upload-alt tm-upload-icon"
                              onclick="document.getElementById('fileInput').click();"
                            ></i>
                          </div>
                          <div class="custom-file mt-3 mb-3">
                            <input id="fileInput" type="file" 
                            accept="image/png, image/jpg, image/jpeg"  
                            name= "p_image" 
                            style="display:none;" />
                            <input
                              type="button"
                              class="btn btn-primary btn-block mx-auto"
                              value="UPLOAD PRODUCT IMAGE"
                              onclick="document.getElementById('fileInput').click();" /*fileInput*/
                            />
                          </div>
                        </div>
                        <div class="col-12">
                          <button type="submit" name="add_product" class="btn btn-primary btn-block text-uppercase">Add Product Now</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
	</div>
</section>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
  $(".user").click(function(){
    $(".profile-div").toggle(1000);
  });
  $(".hicon:nth-child(1)").click(function(){
    $(".notification-div").toggle(1000);
  });
  $(".sicon").click(function(){
    $(".search").toggle(1000);
  });
});
</script>

<script type="text/javascript">
	$('li').click(function(){
    $('li').removeClass("active");
    $(this).addClass("active");
});



	
</script>
</body>
</html>