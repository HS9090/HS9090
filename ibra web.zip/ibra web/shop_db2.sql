-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 30, 2022 at 12:23 PM
-- Server version: 8.0.27
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db2`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `p_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `p_price` int NOT NULL,
  `p_image` varchar(250) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_name`, `p_price`, `p_image`, `quantity`) VALUES
(22, '', 0, '', 1),
(23, 'xxsss', 5555, 'pr2.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `number` int NOT NULL,
  `email` varchar(250) COLLATE utf8_croatian_ci NOT NULL,
  `method` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `flat` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `street` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `city` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `state` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `country` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `total_products` int NOT NULL,
  `total_price` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8_croatian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `p_name` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `p_price` int NOT NULL,
  `p_image` varchar(250) COLLATE utf8_croatian_ci NOT NULL,
  `description` varchar(20) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `p_name`, `p_price`, `p_image`, `description`) VALUES
(19, 'xxsss', 5555, 'pr2.jpg', 'dwcdcd'),
(20, 'ddd', 1323, 'pr4.jpg', 'ssss');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_croatian_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_croatian_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
